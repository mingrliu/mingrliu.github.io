#!/usr/bin/env bash
wget --no-check-certificate --content-disposition https://raw.githubusercontent.com/Junting98/language_data/master/language_data.zip

unzip language_data.zip
rm language_data.zip
